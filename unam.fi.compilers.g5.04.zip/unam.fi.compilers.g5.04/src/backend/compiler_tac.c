#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MAX_LINE 256

/* Quita espacios al inicio y final de la cadena */
void trim(char *s) {
    int i = 0;
    while (isspace((unsigned char)s[i])) i++;
    if (i > 0) memmove(s, s + i, strlen(s) - i + 1);

    int len = (int)strlen(s);
    while (len > 0 && isspace((unsigned char)s[len - 1])) {
        s[len - 1] = '\0';
        len--;
    }
}

/* ¿Es línea vacía o comentario? (# o //) */
int vacia_o_comentario(const char *s) {
    int i;
    for (i = 0; s[i]; i++) {
        if (!isspace((unsigned char)s[i])) {
            if (s[i] == '#' || (s[i] == '/' && s[i+1] == '/')) return 1;
            return 0;
        }
    }
    return 1;
}

/* Relacional TAC -> instrucción de salto */
const char *relop_to_jump(const char *relop) {
    if (strcmp(relop, "<")  == 0) return "JLT";
    if (strcmp(relop, "<=") == 0) return "JLE";
    if (strcmp(relop, ">")  == 0) return "JGT";
    if (strcmp(relop, ">=") == 0) return "JGE";
    if (strcmp(relop, "==") == 0) return "JEQ";
    if (strcmp(relop, "!=") == 0) return "JNE";
    return NULL;
}

/* Operador aritmético TAC -> instrucción */
const char *op_to_instr(const char *op) {
    if (strcmp(op, "+") == 0) return "ADD";
    if (strcmp(op, "-") == 0) return "SUB";
    if (strcmp(op, "*") == 0) return "MUL";
    if (strcmp(op, "/") == 0) return "DIV";
    return NULL;
}

int main(int argc, char *argv[]) {
    if (argc < 3) {
        fprintf(stderr, "Uso: %s entrada.tac salida.asm\n", argv[0]);
        return 1;
    }

    FILE *fin = fopen(argv[1], "r");
    if (!fin) {
        perror("No se pudo abrir archivo TAC de entrada");
        return 1;
    }

    FILE *fout = fopen(argv[2], "w");
    if (!fout) {
        perror("No se pudo crear archivo ASM de salida");
        fclose(fin);
        return 1;
    }

    char line[MAX_LINE];

    while (fgets(line, sizeof(line), fin)) {
        trim(line);
        if (vacia_o_comentario(line)) continue;

        /* 1) Etiquetas: L1: */
        {
            size_t len = strlen(line);
            if (len > 0 && line[len - 1] == ':') {
                fprintf(fout, "%s\n", line);
                continue;
            }
        }

        /* Copia para tokenizar */
        char temp[MAX_LINE];
        strcpy(temp, line);

        /* 2) if x < y goto L1 */
        if (strncmp(temp, "if", 2) == 0 && isspace((unsigned char)temp[2])) {
            char *tok = strtok(temp, " \t"); /* "if" */
            char *x   = strtok(NULL, " \t");
            char *rel = strtok(NULL, " \t");
            char *y   = strtok(NULL, " \t");
            char *g   = strtok(NULL, " \t"); /* "goto" */
            char *L   = strtok(NULL, " \t");

            if (!x || !rel || !y || !g || !L) {
                fprintf(stderr, "Línea TAC inválida (if): %s\n", line);
                continue;
            }

            const char *jump = relop_to_jump(rel);
            if (!jump) {
                fprintf(stderr, "Operador relacional no soportado: %s\n", rel);
                continue;
            }

            /* limpiar ; o , del final del label */
            {
                int i;
                for (i = 0; L[i]; i++) {
                    if (L[i] == ';' || L[i] == ',') { L[i] = '\0'; break; }
                }
            }

            fprintf(fout, "LOAD A, %s\n", x);
            fprintf(fout, "CMP  A, %s\n", y);
            fprintf(fout, "%s %s\n\n", jump, L);
            continue;
        }

        /* 3) goto L */
        if (strncmp(temp, "goto", 4) == 0 || strncmp(temp, "GOTO", 4) == 0) {
            char *tok = strtok(temp, " \t");
            char *L   = strtok(NULL, " \t");
            if (!L) {
                fprintf(stderr, "Línea TAC inválida (goto): %s\n", line);
                continue;
            }
            {
                int i;
                for (i = 0; L[i]; i++) {
                    if (L[i] == ';') { L[i] = '\0'; break; }
                }
            }
            fprintf(fout, "JMP %s\n\n", L);
            continue;
        }

        /* 4) print x  /  print(x) */
        if (strncmp(temp, "print", 5) == 0) {
            char var[64] = {0};
            char *p = strchr(temp, '(');
            if (p) {
                p++;
                char *q = strchr(p, ')');
                if (q) *q = '\0';
                trim(p);
                strcpy(var, p);
            } else {
                char *tok = strtok(temp, " \t");
                char *x   = strtok(NULL, " \t");
                if (x) {
                    trim(x);
                    strcpy(var, x);
                }
            }
            if (var[0] == '\0') {
                fprintf(stderr, "print sin argumento: %s\n", line);
                continue;
            }
            fprintf(fout, "PRINT %s\n\n", var);
            continue;
        }

        /* 5) Asignaciones: x = ... */
        {
            char *eq = strchr(temp, '=');
            if (eq) {
                *eq = '\0';
                char *lhs = temp;
                char *rhs = eq + 1;
                trim(lhs);
                trim(rhs);

                char rhs_copy[MAX_LINE];
                strcpy(rhs_copy, rhs);
                char *t1 = strtok(rhs_copy, " \t");
                char *t2 = strtok(NULL, " \t");
                char *t3 = strtok(NULL, " \t");

                if (t1 && t2 && t3) {
                    /* x = y op z */
                    const char *instr = op_to_instr(t2);
                    if (!instr) {
                        fprintf(stderr, "Operador no soportado: %s\n", t2);
                        continue;
                    }
                    fprintf(fout, "LOAD A, %s\n", t1);
                    fprintf(fout, "%s A, %s\n", instr, t3);
                    fprintf(fout, "STORE A, %s\n\n", lhs);
                } else if (t1 && !t2) {
                    /* x = y */
                    fprintf(fout, "LOAD A, %s\n", t1);
                    fprintf(fout, "STORE A, %s\n\n", lhs);
                } else {
                    fprintf(stderr, "Asignación no reconocida: %s\n", line);
                }
                continue;
            }
        }

        /* Si llega aquí, no entendimos la línea */
        fprintf(stderr, "Línea TAC no reconocida: %s\n", line);
    }

    fprintf(fout, "HALT\n");
    fclose(fin);
    fclose(fout);

    printf("Compilación TAC -> ASM completada.\n");
    return 0;
}
