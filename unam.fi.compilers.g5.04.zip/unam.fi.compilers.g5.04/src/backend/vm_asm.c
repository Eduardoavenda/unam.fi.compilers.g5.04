#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MAX_LINE    256
#define MAX_PROG    512
#define MAX_SYMBOLS 128
#define MAX_LABELS  128

typedef enum {
    OP_LOAD, OP_STORE, OP_ADD, OP_SUB, OP_MUL, OP_DIV,
    OP_CMP,
    OP_JLT, OP_JLE, OP_JGT, OP_JGE, OP_JEQ, OP_JNE,
    OP_JMP,
    OP_PRINT,
    OP_HALT
} OpCode;

typedef struct {
    OpCode op;
    char   arg[32];
    int    target;
    int    line;
} Instr;

typedef struct {
    char name[32];
    int  value;
    int  initialized;
} Symbol;

typedef struct {
    char name[32];
    int  index;
} Label;

static Instr  prog[MAX_PROG];
static int    prog_size = 0;
static Symbol symbols[MAX_SYMBOLS];
static int    symbol_count = 0;
static Label  labels[MAX_LABELS];
static int    label_count = 0;

void trim(char *s) {
    int i = 0;
    while (isspace((unsigned char)s[i])) i++;
    if (i > 0) memmove(s, s + i, strlen(s) - i + 1);
    int len = (int)strlen(s);
    while (len > 0 && isspace((unsigned char)s[len - 1])) {
        s[len - 1] = '\0';
        len--;
    }
}

int empty_or_comment(const char *s) {
    for (int i = 0; s[i]; i++) {
        if (!isspace((unsigned char)s[i])) return 0;
    }
    return 1;
}

int find_symbol(const char *name) {
    for (int i = 0; i < symbol_count; i++) {
        if (strcmp(symbols[i].name, name) == 0) return i;
    }
    return -1;
}

int get_symbol_index(const char *name) {
    int idx = find_symbol(name);
    if (idx != -1) return idx;
    if (symbol_count >= MAX_SYMBOLS) {
        printf("error in line 0\n");
        exit(1);
    }
    strncpy(symbols[symbol_count].name, name,
            sizeof(symbols[symbol_count].name)-1);
    symbols[symbol_count].name[sizeof(symbols[symbol_count].name)-1] = '\0';
    symbols[symbol_count].value = 0;
    symbols[symbol_count].initialized = 0;
    return symbol_count++;
}

int is_number(const char *s) {
    if (*s == '-' || *s == '+') s++;
    if (!isdigit((unsigned char)*s)) return 0;
    s++;
    while (*s) {
        if (!isdigit((unsigned char)*s)) return 0;
        s++;
    }
    return 1;
}

int get_value(const char *token) {
    if (is_number(token)) {
        return atoi(token);
    } else {
        int idx = get_symbol_index(token);
        return symbols[idx].value;
    }
}

void set_value(const char *name, int value) {
    int idx = get_symbol_index(name);
    symbols[idx].value = value;
    symbols[idx].initialized = 1;
}

int find_label_index(const char *name) {
    for (int i = 0; i < label_count; i++) {
        if (strcmp(labels[i].name, name) == 0) return labels[i].index;
    }
    return -1;
}

OpCode mnemonic_to_opcode(const char *m) {
    if (strcmp(m, "LOAD")  == 0) return OP_LOAD;
    if (strcmp(m, "STORE") == 0) return OP_STORE;
    if (strcmp(m, "ADD")   == 0) return OP_ADD;
    if (strcmp(m, "SUB")   == 0) return OP_SUB;
    if (strcmp(m, "MUL")   == 0) return OP_MUL;
    if (strcmp(m, "DIV")   == 0) return OP_DIV;
    if (strcmp(m, "CMP")   == 0) return OP_CMP;
    if (strcmp(m, "JLT")   == 0) return OP_JLT;
    if (strcmp(m, "JLE")   == 0) return OP_JLE;
    if (strcmp(m, "JGT")   == 0) return OP_JGT;
    if (strcmp(m, "JGE")   == 0) return OP_JGE;
    if (strcmp(m, "JEQ")   == 0) return OP_JEQ;
    if (strcmp(m, "JNE")   == 0) return OP_JNE;
    if (strcmp(m, "JMP")   == 0) return OP_JMP;
    if (strcmp(m, "PRINT") == 0) return OP_PRINT;
    if (strcmp(m, "HALT")  == 0) return OP_HALT;
    return -1;
}

int parse_asm(const char *filename) {
    FILE *f = fopen(filename, "r");
    if (!f) return 0;

    char line[MAX_LINE];
    int src_line = 0;

    while (fgets(line, sizeof(line), f)) {
        src_line++;
        trim(line);
        if (empty_or_comment(line)) continue;

        size_t len = strlen(line);
        if (len > 0 && line[len-1] == ':') {
            if (label_count >= MAX_LABELS) {
                printf("error in line %d\n", src_line);
                fclose(f);
                return 0;
            }
            line[len-1] = '\0';
            trim(line);
            strncpy(labels[label_count].name, line,
                    sizeof(labels[label_count].name)-1);
            labels[label_count].name[sizeof(labels[label_count].name)-1] = '\0';
            labels[label_count].index = prog_size;
            label_count++;
            continue;
        }

        char tmp[MAX_LINE];
        strcpy(tmp, line);
        char *mn = strtok(tmp, " \t");
        if (!mn) continue;

        OpCode op = mnemonic_to_opcode(mn);
        if (op == -1) {
            printf("error in line %d\n", src_line);
            fclose(f);
            return 0;
        }

        Instr inst;
        memset(&inst, 0, sizeof(inst));
        inst.op   = op;
        inst.line = src_line;
        inst.target = -1;

        if (op == OP_HALT) {
            
        } else if (op == OP_PRINT || op == OP_JLT || op == OP_JLE ||
                   op == OP_JGT  || op == OP_JGE || op == OP_JEQ ||
                   op == OP_JNE  || op == OP_JMP) {
            char *arg = strtok(NULL, " \t");
            if (!arg) {
                printf("error in line %d\n", src_line);
                fclose(f);
                return 0;
            }
            trim(arg);
            strncpy(inst.arg, arg, sizeof(inst.arg)-1);
        } else {
            /* LOAD A, x   /   ADD A, y   / etc. */
            char *reg  = strtok(NULL, " \t");
            char *coma = strtok(NULL, " \t");
            (void)reg;   
            if (!coma) {
                printf("error in line %d\n", src_line);
                fclose(f);
                return 0;
            }
            trim(coma);
            strncpy(inst.arg, coma, sizeof(inst.arg)-1);
        }

        if (prog_size >= MAX_PROG) {
            printf("error in line %d\n", src_line);
            fclose(f);
            return 0;
        }
        prog[prog_size++] = inst;
    }

    fclose(f);
    return 1;
}

void resolve_jumps(void) {
    for (int i = 0; i < prog_size; i++) {
        Instr *inst = &prog[i];
        if (inst->op == OP_JLT || inst->op == OP_JLE || inst->op == OP_JGT ||
            inst->op == OP_JGE || inst->op == OP_JEQ || inst->op == OP_JNE ||
            inst->op == OP_JMP) {
            int idx = find_label_index(inst->arg);
            if (idx == -1) {
                printf("error in line %d\n", inst->line);
                exit(1);
            }
            inst->target = idx;
        }
    }
}

void execute_program(void) {
    int A = 0;
    int pc = 0;
    int flag_lt = 0, flag_eq = 0, flag_gt = 0;

    while (pc < prog_size) {
        Instr *inst = &prog[pc];

        switch (inst->op) {
            case OP_LOAD:
                A = get_value(inst->arg);
                pc++;
                break;
            case OP_STORE:
                set_value(inst->arg, A);
                pc++;
                break;
            case OP_ADD:
                A += get_value(inst->arg);
                pc++;
                break;
            case OP_SUB:
                A -= get_value(inst->arg);
                pc++;
                break;
            case OP_MUL:
                A *= get_value(inst->arg);
                pc++;
                break;
            case OP_DIV: {
                int v = get_value(inst->arg);
                if (v == 0) {
                    printf("error in line %d\n", inst->line);
                    return;
                }
                A /= v;
                pc++;
                break;
            }
            case OP_CMP: {
                int v = get_value(inst->arg);
                flag_lt = flag_eq = flag_gt = 0;
                if (A < v)      flag_lt = 1;
                else if (A > v) flag_gt = 1;
                else            flag_eq = 1;
                pc++;
                break;
            }
            case OP_JLT:
                pc = flag_lt ? inst->target : pc + 1;
                break;
            case OP_JLE:
                pc = (flag_lt || flag_eq) ? inst->target : pc + 1;
                break;
            case OP_JGT:
                pc = flag_gt ? inst->target : pc + 1;
                break;
            case OP_JGE:
                pc = (flag_gt || flag_eq) ? inst->target : pc + 1;
                break;
            case OP_JEQ:
                pc = flag_eq ? inst->target : pc + 1;
                break;
            case OP_JNE:
                pc = (!flag_eq) ? inst->target : pc + 1;
                break;
            case OP_JMP:
                pc = inst->target;
                break;
            case OP_PRINT: {
                if (inst->arg[0] == '"') {
                    char texto_limpio[MAX_LINE];
                    int len = strlen(inst->arg);
                    
                    if (len >= 2) {
                        strncpy(texto_limpio, inst->arg + 1, len - 2);
                        texto_limpio[len - 2] = '\0';
                    } else {
                        strcpy(texto_limpio, "");
                    }

                    for(int k = 0; texto_limpio[k]; k++) {
                        if(texto_limpio[k] == '~') {
                            texto_limpio[k] = ' ';
                        }
                    }
                    
                    printf("%s\n", texto_limpio);
                } else {
                    int v = get_value(inst->arg);
                    printf("Result of operation: %d\n", v);
                }
                pc++;
                break;
            }
            case OP_HALT:
                return;
        }
    }
}

int main(int argc, char *argv[]) {
    if (argc < 2) {
        printf("Uso: %s programa.asm\n", argv[0]);
        return 1;
    }

    if (!parse_asm(argv[1])) {
        return 1;
    }

    resolve_jumps();
    execute_program();
    return 0;
}

