#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int es_digito(char c) { return c >= '0' && c <= '9'; }
int es_letra(char c)  { return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c == '_'; }
int es_espacio(char c){ return c == ' ' || c == '\t' || c == '\r'; }

int linea_actual = 1; /* Contador global de líneas */

/* Función para enviar tokens al parser */
void enviar_token(const char *tipo, const char *valor) {
    printf("%s %s %d\n", tipo, valor, linea_actual);
}

int main(int argc, char **argv) {
    FILE *entrada = stdin;
    if (argc > 1) {
        entrada = fopen(argv[1], "r");
        if (!entrada) return 1;
    }

    char c;
    char buffer[256]; 
    
    while ((c = fgetc(entrada)) != EOF) {
        /* 1. Manejo de salto de línea */
        if (c == '\n') {
            linea_actual++;
            continue;
        }
        if (es_espacio(c)) continue;

        /* 2. Identificadores y Palabras Clave */
        if (es_letra(c)) {
            int i = 0;
            buffer[i++] = c;
            while (es_letra(c = fgetc(entrada)) || es_digito(c)) {
                buffer[i++] = c;
            }
            buffer[i] = '\0';
            ungetc(c, entrada);

            if (strcmp(buffer, "int") == 0)        enviar_token("TOK_INT", buffer);
            else if (strcmp(buffer, "if") == 0)    enviar_token("TOK_IF", buffer);
            else if (strcmp(buffer, "else") == 0)  enviar_token("TOK_ELSE", buffer);
            else if (strcmp(buffer, "while") == 0) enviar_token("TOK_WHILE", buffer);
            else if (strcmp(buffer, "print") == 0) enviar_token("TOK_PRINT", buffer);
            else                                   enviar_token("TOK_ID", buffer);
        }
        
        /* 3. Números */
        else if (es_digito(c)) {
            int i = 0;
            buffer[i++] = c;
            while (es_digito(c = fgetc(entrada))) {
                buffer[i++] = c;
            }
            buffer[i] = '\0';
            ungetc(c, entrada);
            enviar_token("TOK_NUM", buffer);
        }

        /* 4. CADENAS DE TEXTO (STRINGS) */
        else if (c == '"') {
            int i = 0;
            buffer[i++] = '"'; 
            
            while ((c = fgetc(entrada)) != EOF && c != '"') {
                if (c == ' ') {
                    buffer[i++] = '~'; 
                } else {
                    buffer[i++] = c;
                }
            }
            if (c == '"') {
                buffer[i++] = '"';
            }
            buffer[i] = '\0';
            
            enviar_token("TOK_STRING", buffer);
        }

        /* 5. Operadores y Puntuación */
        else {
            if (c == '=') {
                char sig = fgetc(entrada);
                if (sig == '=') enviar_token("TOK_EQ", "==");
                else { ungetc(sig, entrada); enviar_token("TOK_ASSIGN", "="); }
            }
            else if (c == '<') {
                char sig = fgetc(entrada);
                if (sig == '=') enviar_token("TOK_LTE", "<=");
                else { ungetc(sig, entrada); enviar_token("TOK_LT", "<"); }
            }
            else if (c == '>') {
                char sig = fgetc(entrada);
                if (sig == '=') enviar_token("TOK_GTE", ">=");
                else { ungetc(sig, entrada); enviar_token("TOK_GT", ">"); }
            }
            else if (c == '+') enviar_token("TOK_PLUS", "+");
            else if (c == '-') enviar_token("TOK_MINUS", "-");
            else if (c == '*') enviar_token("TOK_MUL", "*");
            else if (c == '/') enviar_token("TOK_DIV", "/");
            else if (c == '(') enviar_token("TOK_LPAREN", "(");
            else if (c == ')') enviar_token("TOK_RPAREN", ")");
            else if (c == '{') enviar_token("TOK_LBRACE", "{");
            else if (c == '}') enviar_token("TOK_RBRACE", "}");
            else if (c == ';') enviar_token("TOK_SEMI", ";");
        }
    }
    
    enviar_token("TOK_EOF", "EOF");
    if (entrada != stdin) fclose(entrada);
    return 0;
}