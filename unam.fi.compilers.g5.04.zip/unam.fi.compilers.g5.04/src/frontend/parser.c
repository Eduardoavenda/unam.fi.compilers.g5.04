#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* --- ESTRUCTURAS Y GLOBALES --- */
typedef enum {
    TOK_INT, TOK_IF, TOK_ELSE, TOK_WHILE, TOK_PRINT,
    TOK_ID, TOK_NUM, TOK_STRING, 
    TOK_PLUS, TOK_MINUS, TOK_MUL, TOK_DIV, TOK_ASSIGN,
    TOK_EQ, TOK_LT, TOK_GT, TOK_LTE, TOK_GTE,
    TOK_LPAREN, TOK_RPAREN, TOK_LBRACE, TOK_RBRACE, TOK_SEMI,
    TOK_EOF, TOK_UNKNOWN
} TokenType;

typedef struct {
    TokenType type;
    char value[100];
    int line; 
} Token;

Token current_token;
int temp_count = 0;
int label_count = 0;

/* --- UTILIDADES --- */
char* mi_strdup(const char* s) {
    char* p = malloc(strlen(s) + 1);
    if (p) strcpy(p, s);
    return p;
}

char* new_temp() {
    static char buffer[20];
    sprintf(buffer, "t%d", ++temp_count);
    return mi_strdup(buffer);
}

char* new_label() {
    static char buffer[20];
    sprintf(buffer, "L%d", ++label_count);
    return mi_strdup(buffer);
}

/* --- LECTURA DE TOKENS --- */
void get_next_token() {
    char type_str[50];
    char val_str[100];
    int line_num;

    if (scanf("%s %s %d", type_str, val_str, &line_num) == EOF) {
        current_token.type = TOK_EOF;
        return;
    }

    strcpy(current_token.value, val_str);
    current_token.line = line_num;

    if (strcmp(type_str, "TOK_INT") == 0) current_token.type = TOK_INT;
    else if (strcmp(type_str, "TOK_IF") == 0) current_token.type = TOK_IF;
    else if (strcmp(type_str, "TOK_ELSE") == 0) current_token.type = TOK_ELSE;
    else if (strcmp(type_str, "TOK_WHILE") == 0) current_token.type = TOK_WHILE;
    else if (strcmp(type_str, "TOK_PRINT") == 0) current_token.type = TOK_PRINT;
    else if (strcmp(type_str, "TOK_ID") == 0) current_token.type = TOK_ID;
    else if (strcmp(type_str, "TOK_NUM") == 0) current_token.type = TOK_NUM;
    else if (strcmp(type_str, "TOK_STRING") == 0) current_token.type = TOK_STRING; 
    else if (strcmp(type_str, "TOK_PLUS") == 0) current_token.type = TOK_PLUS;
    else if (strcmp(type_str, "TOK_MINUS") == 0) current_token.type = TOK_MINUS;
    else if (strcmp(type_str, "TOK_MUL") == 0) current_token.type = TOK_MUL;
    else if (strcmp(type_str, "TOK_DIV") == 0) current_token.type = TOK_DIV;
    else if (strcmp(type_str, "TOK_ASSIGN") == 0) current_token.type = TOK_ASSIGN;
    else if (strcmp(type_str, "TOK_EQ") == 0) current_token.type = TOK_EQ;
    else if (strcmp(type_str, "TOK_LT") == 0) current_token.type = TOK_LT;
    else if (strcmp(type_str, "TOK_GT") == 0) current_token.type = TOK_GT;
    else if (strcmp(type_str, "TOK_LTE") == 0) current_token.type = TOK_LTE;
    else if (strcmp(type_str, "TOK_GTE") == 0) current_token.type = TOK_GTE;
    else if (strcmp(type_str, "TOK_LPAREN") == 0) current_token.type = TOK_LPAREN;
    else if (strcmp(type_str, "TOK_RPAREN") == 0) current_token.type = TOK_RPAREN;
    else if (strcmp(type_str, "TOK_LBRACE") == 0) current_token.type = TOK_LBRACE;
    else if (strcmp(type_str, "TOK_RBRACE") == 0) current_token.type = TOK_RBRACE;
    else if (strcmp(type_str, "TOK_SEMI") == 0) current_token.type = TOK_SEMI;
    else if (strcmp(type_str, "TOK_EOF") == 0) current_token.type = TOK_EOF;
    else current_token.type = TOK_UNKNOWN;
}

void match(TokenType type) {
    if (current_token.type == type) {
        get_next_token();
    } else {
        fprintf(stderr, "\n[ERROR DE SINTAXIS]\n");
        fprintf(stderr, "-------------------------\n");
        fprintf(stderr, "Ubicacion: Linea %d\n", current_token.line);
        fprintf(stderr, "Esperado:  Token tipo %d\n", type);
        fprintf(stderr, "Encontrado: '%s'\n", current_token.value);
        fprintf(stderr, "-------------------------\n");
        exit(1);
    }
}

/* --- GRAMÁTICA (TAC) --- */
char* expression();
void statement();

char* factor() {
    char *temp = mi_strdup(current_token.value);
    if (current_token.type == TOK_NUM || current_token.type == TOK_ID) {
        get_next_token();
    } else if (current_token.type == TOK_LPAREN) {
        match(TOK_LPAREN);
        free(temp);
        temp = expression();
        match(TOK_RPAREN);
    }
    return temp;
}

char* term() {
    char *left = factor();
    while (current_token.type == TOK_MUL || current_token.type == TOK_DIV) {
        int is_mul = (current_token.type == TOK_MUL);
        get_next_token();
        char *right = factor();
        char *temp = new_temp();
        printf("\t%s = %s %s %s\n", temp, left, is_mul ? "*" : "/", right);
        left = temp;
    }
    return left;
}

char* expression() {
    char *left = term();
    while (current_token.type == TOK_PLUS || current_token.type == TOK_MINUS ||
           current_token.type == TOK_LT || current_token.type == TOK_GT || 
           current_token.type == TOK_EQ) {
        char op_str[5];
        if (current_token.type == TOK_PLUS) strcpy(op_str, "+");
        else if (current_token.type == TOK_MINUS) strcpy(op_str, "-");
        else if (current_token.type == TOK_LT) strcpy(op_str, "<");
        else if (current_token.type == TOK_GT) strcpy(op_str, ">");
        else if (current_token.type == TOK_EQ) strcpy(op_str, "==");
        get_next_token();
        char *right = term();
        char *temp = new_temp();
        printf("\t%s = %s %s %s\n", temp, left, op_str, right);
        left = temp;
    }
    return left;
}

void statement() {
    /* --- DECLARACION (int x = 5;) --- */
    if (current_token.type == TOK_INT) {
        match(TOK_INT);
        char var_name[100];
        strcpy(var_name, current_token.value);
        match(TOK_ID);
        if (current_token.type == TOK_ASSIGN) {
            match(TOK_ASSIGN);
            char *expr = expression();
            printf("\t%s = %s\n", var_name, expr);
        }
        match(TOK_SEMI);

    /* --- ASIGNACION (x = 5;) --- */
    } else if (current_token.type == TOK_ID) {
        char var_name[100];
        strcpy(var_name, current_token.value);
        match(TOK_ID);
        match(TOK_ASSIGN);
        char *expr = expression();
        printf("\t%s = %s\n", var_name, expr);
        match(TOK_SEMI);

    /* --- PRINT --- */
    } else if (current_token.type == TOK_PRINT) {
        match(TOK_PRINT);
        match(TOK_LPAREN);

        if (current_token.type == TOK_STRING) {
            printf("\tprint %s\n", current_token.value);
            match(TOK_STRING);
        } else {
            char *val = expression();
            printf("\tprint %s\n", val);
        }

        match(TOK_RPAREN);
        match(TOK_SEMI);

    /* --- IF / ELSE --- */
    } else if (current_token.type == TOK_IF) {
        char *L_true  = new_label();
        char *L_false = new_label();
        char *L_end   = new_label();

        match(TOK_IF);
        match(TOK_LPAREN);

        // 1. Condición
        char *lhs = factor();
        char op[5] = "==";
        if (current_token.type == TOK_LT) { strcpy(op, "<"); match(TOK_LT); }
        else if (current_token.type == TOK_GT) { strcpy(op, ">"); match(TOK_GT); }
        else if (current_token.type == TOK_EQ) { strcpy(op, "=="); match(TOK_EQ); }
        else if (current_token.type == TOK_LTE) { strcpy(op, "<="); match(TOK_LTE); }
        else if (current_token.type == TOK_GTE) { strcpy(op, ">="); match(TOK_GTE); }
        
        char *rhs = factor();
        match(TOK_RPAREN);

        // Generar TAC
        printf("\tif %s %s %s goto %s\n", lhs, op, rhs, L_true);
        printf("\tgoto %s\n", L_false);

        // 2. Bloque Verdadero
        printf("%s:\n", L_true);
        statement(); 
        printf("\tgoto %s\n", L_end); 

        // 3. Bloque Falso (Else)
        printf("%s:\n", L_false);
        if (current_token.type == TOK_ELSE) {
            match(TOK_ELSE);
            statement();
        }

        // 4. Fin
        printf("%s:\n", L_end);

    /* --- WHILE --- */
    } else if (current_token.type == TOK_WHILE) {
        char *L_start = new_label();
        char *L_end = new_label();
        printf("%s:\n", L_start);
        match(TOK_WHILE);
        match(TOK_LPAREN);
        
        char *lhs = factor();
        char op_inv[5] = "==";
        if (current_token.type == TOK_LT) { strcpy(op_inv, ">="); match(TOK_LT); }
        else if (current_token.type == TOK_GT) { strcpy(op_inv, "<="); match(TOK_GT); }
        else if (current_token.type == TOK_EQ) { strcpy(op_inv, "!="); match(TOK_EQ); }
        else if (current_token.type == TOK_LTE) { strcpy(op_inv, ">"); match(TOK_LTE); }
        else if (current_token.type == TOK_GTE) { strcpy(op_inv, "<"); match(TOK_GTE); }
        
        char *rhs = factor();
        match(TOK_RPAREN);
        printf("\tif %s %s %s goto %s\n", lhs, op_inv, rhs, L_end);
        statement();
        printf("\tgoto %s\n", L_start);
        printf("%s:\n", L_end);

    /* --- BLOQUE { ... } --- */
    } else if (current_token.type == TOK_LBRACE) {
        match(TOK_LBRACE);
        while (current_token.type != TOK_RBRACE && current_token.type != TOK_EOF) {
            statement();
        }
        match(TOK_RBRACE);
    } else {
        get_next_token();
    }
}

int main() {
    get_next_token();
    while (current_token.type != TOK_EOF) {
        statement();
    }
    return 0;
}