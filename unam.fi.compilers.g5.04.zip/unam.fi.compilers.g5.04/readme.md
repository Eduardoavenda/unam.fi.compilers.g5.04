Antes de ejecutar el proyecto, es necesario compilar los 4 módulos principales. Abra su terminal en la carpeta raíz del proyecto y ejecute los siguientes comandos en orden:

1. Compilar el Frontend (Análisis)
DOS

gcc src/frontend/lexer.c -o bin/lexer.exe
gcc src/frontend/parser.c -o bin/parser.exe

2. Compilar el Backend (Síntesis)
DOS

gcc src/backend/compiler_tac.c -o bin/compiler_tac.exe
gcc src/backend/vm_asm.c -o bin/vm_asm.exe

Nota: Asegúrese de que la carpeta bin exista. Si no, créela con mkdir bin.

Interfaz Gráfica
Un entorno visual estilo IDE que permite escribir código, compilar y ver la salida en una consola integrada. Requiere tener Python instalado.

Comando:

python ide.py

Opción B: Línea de Comandos (Ejecutar el codigo
desde la terminal por si no quieren hacerlo en 
la intefaz

ej: C:\unam.fi.compilers.g5.04>run.bat examples\espacios.txt
)
Utilice el script run.bat para procesar un archivo de texto directamente. Este script conecta todas las etapas del compilador automáticamente.

Comando:

run.bat examples\archivo_prueba.txt