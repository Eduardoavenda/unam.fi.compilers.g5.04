import tkinter as tk
from tkinter import scrolledtext, messagebox
import subprocess
import os

# Configuración de colores 
BG_COLOR = "#1e1e1e"       
TEXT_COLOR = "#d4d4d4"    
EDITOR_BG = "#252526"      
CONSOLE_BG = "#1e1e1e"     
BUTTON_BG = "#0e639c"      
BUTTON_FG = "white"

def ejecutar_compilador():

    codigo = editor.get("1.0", tk.END).strip()
    
    if not codigo:
        messagebox.showwarning("Advertencia", "El editor está vacío.")
        return

    # 2. Guardar el código en un archivo temporal
    archivo_temp = os.path.join("examples", "temp_gui.txt")
    
    if not os.path.exists("examples"):
        os.makedirs("examples")

    with open(archivo_temp, "w") as f:
        f.write(codigo)

    # 3. Limpiar consola 
    consola.config(state=tk.NORMAL)
    consola.delete("1.0", tk.END)
    consola.insert(tk.END, ">>> Compilando y ejecutando...\n", "info")
    consola.update()

    # 4. Llamar al run.bat usando subprocess
    try:
        proceso = subprocess.run(
            ["run.bat", archivo_temp], 
            capture_output=True, 
            text=True, 
            shell=True
        )
        
        # 5. Mostrar resultados en la consola
        salida = proceso.stdout
        error = proceso.stderr

        if proceso.returncode != 0:
             consola.insert(tk.END, "\n[ERROR DETECTADO]\n", "error_title")
             if error: consola.insert(tk.END, error, "error")
             if salida: consola.insert(tk.END, salida) 
        else:
            consola.insert(tk.END, salida)
            consola.insert(tk.END, "\n[PROCESO TERMINADO CON EXITO]\n", "success")

    except Exception as e:
        consola.insert(tk.END, f"\nError crítico al ejecutar: {e}", "error")

    consola.config(state=tk.DISABLED) 

# --- CONFIGURACIÓN DE LA VENTANA ---
root = tk.Tk()
root.title("Compiler G5 IDE - UNAM")
root.geometry("800x600")
root.configure(bg=BG_COLOR)

# Título superior
lbl_titulo = tk.Label(root, text="Editor de Código Fuente", bg=BG_COLOR, fg=TEXT_COLOR, font=("Consolas", 12, "bold"))
lbl_titulo.pack(pady=5)

# Área del Editor
editor = scrolledtext.ScrolledText(root, wrap=tk.WORD, bg=EDITOR_BG, fg=TEXT_COLOR, 
                                   insertbackground="white", font=("Consolas", 11))
editor.pack(expand=True, fill='both', padx=10, pady=5)

# Botón de Ejecutar
btn_run = tk.Button(root, text="▶ COMPILAR Y EJECUTAR", command=ejecutar_compilador, 
                    bg=BUTTON_BG, fg=BUTTON_FG, font=("Segoe UI", 10, "bold"), 
                    activebackground="#1177bb", activeforeground="white", cursor="hand2")
btn_run.pack(pady=5, fill='x', padx=10)

# Título Consola
lbl_consola = tk.Label(root, text="Salida / Consola", bg=BG_COLOR, fg=TEXT_COLOR, font=("Consolas", 10, "bold"))
lbl_consola.pack(pady=(10, 0), anchor="w", padx=10)

# Área de Consola 
consola = scrolledtext.ScrolledText(root, height=10, bg=CONSOLE_BG, fg="#cccccc", 
                                    font=("Consolas", 10), state=tk.DISABLED)
consola.pack(fill='x', padx=10, pady=(0, 10))

consola.tag_config("error", foreground="#ff4d4d")       
consola.tag_config("error_title", foreground="#ff0000", font=("Consolas", 10, "bold"))
consola.tag_config("success", foreground="#4caf50")     
consola.tag_config("info", foreground="#569cd6")        

root.mainloop()